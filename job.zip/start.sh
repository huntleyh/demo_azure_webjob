#!/bin/bash
/opt/python/3.12.2/bin/pip3.12 install -r requirements.txt
/opt/python/3.12.2/bin/python3.12 job.py